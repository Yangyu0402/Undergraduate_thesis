import numpy as np
from sklearn.decomposition import PCA
import xlrd
from imblearn.over_sampling import SMOTE
from sklearn.ensemble import RandomForestClassifier
from sklearn import svm
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import confusion_matrix
from sklearn.preprocessing import MinMaxScaler
import re
import sklearn
import math
from sklearn.model_selection import cross_val_predict



# excel表数据转换为矩阵
def excel2m(path):
    data = xlrd.open_workbook(path)
    table = data.sheets()[0]
    nrows = table.nrows
    ncols = table.ncols
    datamatrix = np.zeros((nrows, ncols))
    for x in range(ncols):
        cols = table.col_values(x)
        cols1 = np.matrix(cols)
        datamatrix[:, x] = cols1
    return datamatrix

# 寻找文本中特定字符
def findall(x, y):
    index_list = [i.start() for i in re.finditer(x, y)]
    return index_list

#特征提取
seq = []
line = ''
m = open('C:/Users/yang/Desktop/Code/Data-S1.txt', 'r')
for line in m.readlines():
    if line.startswith('A'):
        seq.append(line.strip())
    if line.startswith('C'):
        seq.append(line.strip())
    if line.startswith('G'):
        seq.append(line.strip())
    if line.startswith('T'):
        seq.append(line.strip())
value_na = ['AA', 'TT', 'AT', 'AG', 'CT', 'AC', 'GT', 'TA', 'TG', 'CA', 'TC', 'GA', 'GG', 'CC', 'GC', 'CG']
Pro = np.array(excel2m('C:/Users/yang/Desktop/Code/pro.xlsx'))
Pro_Nm = np.transpose(MinMaxScaler().fit_transform(np.transpose(Pro)))
matrix = []
for t in range(0, len(seq)):
    value_matrix = np.zeros((len(seq[t]) - 1, Pro_Nm.shape[0]))
    words = []
    words_1 = []
    for word in seq[t]:
        words += word
    del (words[-1])
    for word1 in seq[t]:
        words_1 += word1
    del (words_1[0])
    word_sum = []
    for i in range(len(words)):
        word_sum.append(words[i] + words_1[i])
    for i in range(len(word_sum)):
        for ii in range(len(value_na)):
            if word_sum[i] == value_na[ii]:
                for x in range(Pro_Nm.shape[0]):
                    value_matrix[i][x] = Pro_Nm[x][ii]
    matrix.append(value_matrix)
result = np.zeros((15, 15))
G = np.zeros((225, 5))
feature = np.zeros((1017, 1125))
for i in range(1017):
    value_matrix = matrix[i]
    for g in range(5):
        for s in range(15):
            value_s = value_matrix[:, s]
            csg1 = value_matrix[0:len(seq[i]) - 1 - g - 1, s]
            csg2 = value_matrix[1 + g:len(seq[i]), s]
            for t in range(15):
                value_t = value_matrix[:, t]
                denominator = sum((value_s - value_s.mean() * (value_t - value_t.mean())))
                denominator = denominator / (len(seq[i]) - 1 - 1)
                ctg1 = value_matrix[0:len(seq[i]) - 1 - g - 1, t]
                ctg2 = value_matrix[1 + g:len(seq[i]), t]
                numerator = sum(np.multiply((csg1 - csg2), (ctg1 - ctg2)))
                numerator = numerator / (2 * (len(seq[i]) - 1 - g))
                result[s, t] = numerator / denominator
        x = 0
        while x < result.shape[0] * result.shape[1]:
            for cols in range(result.shape[1]):
                for rows in range(result.shape[0]):
                    G[x, g] = result[rows][cols]
                    x += 1
    x = 0
    while x < G.shape[0] * G.shape[1]:
        for cols in range(G.shape[1]):
            for rows in range(G.shape[0]):
                G1 = np.transpose(G)
                feature[i, x] = G1[cols][rows]
                x += 1


# PCA处理
def data_process():
    i = 3
    var = 0
    while var <= 0.95:
        pca = PCA(n_components=i)
        pca.fit(feature)
        var = sum(pca.explained_variance_ratio_)
        i += 1
    new_data = pca.fit_transform(feature)
    return new_data


# SMOTE处理数据
def smote():
    global X_smo
    global y_smo
    X = data_process()
    Y = []
    for x in range(280):
        Y.append(0)
    for x in range(737):
        Y.append(1)
    new_X = []
    for arr in X:
        new_X.append(list(arr))
    new_y = Y
    smo = SMOTE(random_state=42)
    X_smo, y_smo = smo.fit_sample(new_X, new_y)
    return X_smo, y_smo


smote()


# 混淆矩阵
def evaluate():
    global Confusion_Matrix, sn, sp, acc, mcc
    Confusion_Matrix = sklearn.metrics.confusion_matrix(y_smo, y_pred, labels=[0, 1], sample_weight=None)
    Confusion_Matrix = Confusion_Matrix.tolist()
    sn = round(Confusion_Matrix[0][0] / (Confusion_Matrix[0][0] + Confusion_Matrix[1][0]), 4) * 100
    sp = round(Confusion_Matrix[1][1] / (Confusion_Matrix[0][1] + Confusion_Matrix[1][1]), 4) * 100
    acc = round((Confusion_Matrix[0][0] + Confusion_Matrix[1][1]) / (
            Confusion_Matrix[0][0] + Confusion_Matrix[0][1] + Confusion_Matrix[1][0] + Confusion_Matrix[1][1]), 4) * 100
    mcc = round(
        (1 - Confusion_Matrix[1][0] / (Confusion_Matrix[0][0] + Confusion_Matrix[1][0]) - Confusion_Matrix[0][1] / (
                Confusion_Matrix[0][1] + Confusion_Matrix[1][1])) / math.sqrt(
            (1 + (Confusion_Matrix[0][1] - Confusion_Matrix[1][0]) / (
                    Confusion_Matrix[0][0] + Confusion_Matrix[1][0])) * (
                    1 + (Confusion_Matrix[1][0] - Confusion_Matrix[0][1]) / (
                    Confusion_Matrix[0][1] + Confusion_Matrix[1][1]))), 4) * 100
    Confusion_Matrix = np.array(Confusion_Matrix)
    return Confusion_Matrix, sn, sp, acc, mcc


# 随机森林分类
rf = RandomForestClassifier(n_estimators=10, max_depth=None, min_samples_split=2, random_state=0)
y_pred = cross_val_predict(rf, X_smo, y_smo, cv=10)
evaluate()
print(f"Random Forest:\nsn: {sn}%\nsp: {sp}%\nacc: {acc}%\nmcc: {mcc}%")
print(f'confusion matrix:\n{Confusion_Matrix}\n')
# 支持向量机分类
svm = svm.SVC(C=0.8, kernel='rbf', gamma=20, decision_function_shape='ovr', random_state=0)
y_pred = cross_val_predict(svm, X_smo, y_smo, cv=10)
evaluate()
print(f"SVM:\nsn: {sn}%\nsp: {sp}%\nacc: {acc}%\nmcc: {mcc}%")
print(f'confusion matrix:\n{Confusion_Matrix}\n')
# 朴素贝叶斯分类
nb = GaussianNB()
y_pred = cross_val_predict(nb, X_smo, y_smo, cv=10)
evaluate()
print(f"Bayes:\nsn: {sn}%\nsp: {sp}%\nacc: {acc}%\nmcc: {mcc}%")
print(f'confusion matrix:\n{Confusion_Matrix}\n')
